const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const vendorRoutes = require('./routes/vendorRoutes')
const bodyParser = require('body-parser')
const firmRoutes = require('./routes/firmRoutes')

const app = express();

const PORT = 4000;

app.listen(PORT, () => {
  console.log(`Server Started at Port ${PORT}`);
});

dotenv.config();

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("Database connected"))
  .catch((error) => console.log(error));

app.use("/home", (req, res) => {
  res.send("<h1> Welcome </h1>");
});

app.use(bodyParser.json())
app.use('/vendor', vendorRoutes)
app.use('/firm', firmRoutes)